local PlayerData                = {}
ESX                             = nil
 
Citizen.CreateThread(function()
  while ESX == nil do
   TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
   Citizen.Wait(0)
  end
 
  while ESX.GetPlayerData().job == nil do
   Citizen.Wait(10)
  end
 
 PlayerData = ESX.GetPlayerData()
end)
 
RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  PlayerData.job = job
end)


function blipolustur(x, y, sprite, colour, scale, text)
  local blip = AddBlipForCoord(x, y)
  SetBlipSprite(blip, sprite)
  SetBlipColour(blip, colour)
  SetBlipAsShortRange(blip, true)
  SetBlipScale(blip, scale)
  BeginTextCommandSetBlipName("STRING")
  AddTextComponentString(text)
  EndTextCommandSetBlipName(blip)
  table.insert(blipshs, blip)
end




local swencykiy = {
    [1] = {x = 1693.45667, y = 4823.17725, z = 42.1631294, kiyafetciid = 1, info = 'kiyafetci 1'},
    [2] = {x = -1177.865234375, y = -1780.5612792969, z = 3.9084651470184, kiyafetciid = 2, info = 'kiyafetci 2'},
    [3] = {x = 299.29, y = -598.45, z = 43.29, kiyafetciid = 3, info = 'kiyafetci 3'},
    [4] = {x = -712.215881, y = -155.352982, z = 37.4151268, kiyafetciid = 4, info = 'kiyafetci 4'},
    [5] = {x = 123.779823, y = -301.616455, z = 54.557827, kiyafetciid = 5, info = 'kiyafetci 5'},
    [6] = {x = 121.76, y = -224.6, z = 53.56, kiyafetciid = 6, info = 'kiyafetci 6'},
    [7] = {x = -1192.94495, y = -772.688965, z = 17.3255997, kiyafetciid = 7, info = 'kiyafetci 7'},  
    [8] = {x = 454.75, y = -991.05, z = 30.69, kiyafetciid = 8, info = 'kiyafetci 8'},
    [9] = {x = 425.236, y = -806.008, z = 28.491, kiyafetciid = 9, info = 'kiyafetci 9'},
    [10] = {x = -162.658, y = -303.397, z = 38.733, kiyafetciid = 10, info = 'kiyafetci 10'},
    [11] = {x = 75.950, y = -1392.891, z = 28.376, kiyafetciid = 11, info = 'kiyafetci 11'},
    [12] = {x = -822.194, y = -1074.134, z = 10.328, kiyafetciid = 12, info = 'kiyafetci 12'}, 
    [13] = {x = -1450.711, y = -236.83, z = 48.809, kiyafetciid = 13, info = 'kiyafetci 13'},
    [14] = {x = 4.254, y = 6512.813, z = 30.877, kiyafetciid = 14, info = 'kiyafetci 14'},
    [15] = {x = 615.180, y = 2762.933, z = 41.088, kiyafetciid = 15, info = 'kiyafetci 15'},
    [16] = {x = 1196.785, y = 2709.558, z = 37.222, kiyafetciid = 16, info = 'kiyafetci 16'},
    [17] = {x = -3171.453, y = 1043.857, z = 19.863, kiyafetciid = 17, info = 'kiyafetci 17'},
    [18] = {x = -1100.959, y = 2710.211, z = 18.107, kiyafetciid = 18, info = 'kiyafetci 18'},
    [19] = {x = -1207.6564941406, y = -1456.8890380859, z = 4.3784737586975, kiyafetciid = 19, info = 'kiyafetci 19'},
    [20] = {x = 1784.13, y = 2492.6, z = 50.43, kiyafetciid = 20, info = 'kiyafetci 20'},
    [21] = {x = 198.4602355957, y = -1646.7690429688, z = 29.803218841553, kiyafetciid = 21, info = 'kiyafetci 21'}
}
  
local bliptrue = false
blipshs = {}
-- RegisterNetEvent('swency:kiyafetci')
-- AddEventHandler('swency:kiyafetci',function()
RegisterCommand('kiyafetciblip', function()
    if not bliptrue then
          bliptrue = true
        for k, v in pairs(swencykiy) do
          blipolustur(v.x,v.y, 73, 0, 0.5, 'Kıyafetçi')
        end
          ESX.ShowNotification('Kıyafetçi blipleri açıldı')
    else
          bliptrue = false
        for k, v in pairs(blipshs) do
              RemoveBlip(v)
        end
          ESX.ShowNotification('Kıyafetçi blipleri kapatıldı')
    end
end)

-------------------------------------------------MARKET---------------------------------------------------


local swencyshop = {
  [1] =	{x = 1961.1140136719, y = 3741.4494628906, z = 32.34375, marketid = 1, info = 'market 1'},
  [2] =	{x = 1392.4129638672, y = 3604.47265625, z = 34.980926513672, marketid = 2, info = 'market 2'},
  [3] =	{x = 546.98962402344, y = 2670.3176269531, z = 42.156539916992, marketid = 3, info = 'market 3'},
  [4] =	{x = 2556.2534179688, y = 382.876953125, z = 108.62294769287, marketid = 4, info = 'market 4'},
  [5]	= {x = -1821.9542236328, y = 792.40191650391, z = 138.13920593262, marketid = 5, info = 'market 5'},
  [6] =	{x = -1223.6690673828, y = -906.67517089844, z = 12.326356887817, marketid = 6, info = 'market 6'},
  [7]	= {x = -708.19256591797, y = -914.65264892578, z = 19.215591430664, marketid = 7, info = 'market 7'},
  [8]	= {x = 26.419162750244, y = -1347.5804443359, z = 29.497024536133, marketid = 8, info = 'market 8'},
  [9]	= {x = -45.4649, y = -1754.41, z = 29.421, marketid = 9, info = 'market 9'},
  [10] =	{x = 1162.87, y = -319.218, z = 69.2051, marketid = 10, info = 'market 10'},
  [11] =	{x = 373.872, y = 331.028, z = 103.566, marketid = 11, info = 'market 11'},
  [12] =	{x = 2673.91, y = 3281.77, z = 55.2411, marketid = 12, info = 'market 12'},
  [13] =	{x = 1701.97, y = 4921.81, z = 42.0637, marketid = 13, info = 'market 13'},
  [14] =	{x = 1730.06, y = 6419.63, z = 35.0372, marketid = 14, info = 'market 14'},
  [15] =	{x = 1841.32, y = 2591.35, z = 46.02, marketid = 15, info = 'market 15'}
}


  -- RegisterNetEvent('swency:market')
  -- AddEventHandler('swency:market',function()
RegisterCommand('marketblip', function()
    if not bliptrue then
        bliptrue = true
        for k, v in pairs(swencyshop) do
          blipolustur(v.x,v.y, 357, 3, 0.5, 'Market')
        end
        ESX.ShowNotification('Market blipleri kapatıldı')
    else
          bliptrue = false
          for k, v in pairs(blipshs) do
              RemoveBlip(v)
          end
          ESX.ShowNotification('Market blipleri açıldı')
    end
end)




-------------------------------------------------GARAJ---------------------------------------------------

local garage = {
  [1] =	vector3(273.67422485352, -344.15573120117, 44.919834136963),
  [2] =	vector3(-1803.8967285156, -341.45928955078, 43.986347198486),
  [3] =	vector3(1893.77, 3712.21, 32.78),
  [4] =	vector3(77.53, 6361.71, 31.49),
  [5]	= vector3(846.2601, -1050.778, 27.95996),
  [6] =	vector3(1107.18, 60.58, 80.89),
  [7]	= vector3(1036.09, -763.36, 57.99),
  [8]	= vector3(56.05059, -876.4091, 30.65991),
  [9]	= vector3(-72.69, 908.39, 235.63),
  [10] =	vector3(-3155.68, 1125.22, 20.86),
  [11] =	vector3(213.8, -809.00, 31.00),
  [12] =	vector3(-52.79, -220.93, 45.44),
  [13] =	vector3(2549.39, 4669.95, 34.08),
  [14] =	vector3(951.42, -122.64, 74.35),
  [15] =	vector3(-1414.61, -653.81, 28.67),
  [16] =	vector3(541.1, -1791.09, 29.14),
  [17] =	vector3(-737.11, 5822.99, 17.31),
  [18] =	vector3(1098.0, 2659.54, 38.14),
  [19] =	vector3(-68.33, -1832.17, 26.94)
}


  -- RegisterNetEvent('swency:garajb')
  -- AddEventHandler('swency:garajb',function()
RegisterCommand('garajblip', function()
    if not bliptrue then
        bliptrue = true
        for k, v in pairs(garage) do
          blipolustur(v.x,v.y, 357, 3, 0.5, 'Garage')
        end
        ESX.ShowNotification('Garage blipleri açıldı')
    else
          bliptrue = false
          for k, v in pairs(blipshs) do
              RemoveBlip(v)
          end
          ESX.ShowNotification('Garage blipleri kapatıldı')
    end
end)