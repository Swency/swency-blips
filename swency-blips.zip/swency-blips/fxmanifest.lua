fx_version 'adamant'

games { 'gta5' }

version '0.1'

client_scripts {
    'client.lua'
}
